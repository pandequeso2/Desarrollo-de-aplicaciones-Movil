package com.example.myaplicacion.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
// ColorScheme ya no es necesario importarlo explícitamente aquí si usas MaterialTheme.colorScheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.MaterialTheme // Importante
import androidx.compose.material3.darkColorScheme // Importante
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color // Importante
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.myaplicacion.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen() {

    // Definición del ColorScheme local que estabas usando
    val localColorScheme = darkColorScheme(
        primary = Color(0xFF03A9F4),    // Color primario para elementos como el fondo de TopAppBar
        onPrimary = Color.White,        // Color para texto/iconos sobre el color primario
        surface = Color(0xFF0F0F0F),    // Color de fondo para superficies como el fondo del Column
        onSurface = Color(0xFF656565)   // Color para texto/iconos sobre el color de superficie
        // Puedes definir otros colores como secondary, background, etc., si los necesitas.
    )

    MaterialTheme(
        colorScheme = localColorScheme // Aplicar el ColorScheme local
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            "Mi primera App"
                            // El color del texto del título se tomará de titleContentColor
                            // o de MaterialTheme.colorScheme.onPrimary si containerColor es primary
                        )
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primary, // Usa el primario del tema local
                        titleContentColor = MaterialTheme.colorScheme.onPrimary // Usa onPrimary del tema local
                    )
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .padding(innerPadding) // Aplica el padding del Scaffold
                    .fillMaxSize()         // El Column ocupa todo el espacio disponible
                    .background(Color(0xFFEFE7E7)) // Fondo del Column usando el tema local
                    .padding(16.dp),       // Padding interno adicional
                verticalArrangement = Arrangement.spacedBy(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Bienvenido a tu primera App",
                    style = MaterialTheme.typography.headlineMedium, // Aplicar un estilo de tipografía del tema
                    color = MaterialTheme.colorScheme.primary // Usar el color primario para este texto destacado
                )

                Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = "Logo",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp),
                    contentScale = ContentScale.Fit
                )

                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Homero Chino",
                        style = MaterialTheme.typography.bodyLarge.copy( // Usar un estilo base y modificarlo
                            fontWeight = FontWeight.Bold
                        ),
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f), // color más suave
                        modifier = Modifier.padding(end = 8.dp) // Corregido: .dp y dentro de los parámetros del Text
                    )
                    Text(
                        text = "Homero ChinoO",
                        style = MaterialTheme.typography.bodyLarge.copy( // Usar un estilo base y modificarlo
                            fontWeight = FontWeight.Bold
                        ),
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f), // color más suave
                        modifier = Modifier.padding(end = 8.dp) // Corregido: .dp y dentro de los parámetros del Text
                    )


                }
                Spacer(modifier = Modifier.height(66.dp))
                Button(onClick = { /* TODO: Implementar acción futura */ }) {
                    Text("Presionar") // El texto del botón usará colores por defecto del tema del botón
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun HomeScreenPreview() {
    HomeScreen()
}
